function h = Plot_RatMap_Head()
%% function h = Plot_RatMap_Head()
% -------------------------------------------------------------------------
% INPUT:
%   none.
% OUTPUT:
%   h - handle to trisurf RatMap_Head object
% -------------------------------------------------------------------------
% NOTES:
%   + RatMap_Head struct contains:
%       .x - x coordinates for point-cloud of head 
%       .y - y coordinates for point-cloud of head
%       .z - z coordinates for point-cloud of head
%       .t - identity of each node for tri-mesh of point-cloud 
%     
%   + Head scanned by Blythe Towal, data processed by Rafay Faruqi
%   + Point-cloud to trimesh achieved using:
%     http://www.mathworks.com/matlabcentral/fileexchange/22595-surface-rec
%     onstruction-from-scattered-points-cloud-part2
% -------------------------------------------------------------------------
% Brian Quist
% March 25, 2011

%% Load the composite head
load RatMap_Head

%% Plotting
hold on;
h = trisurf(RatMap_Head.t,RatMap_Head.x,RatMap_Head.y,RatMap_Head.z, ...
    'FaceColor','k','EdgeColor','none','FaceAlpha',0.2);

%% Formatting
xlabel('x');
ylabel('y');
zlabel('z');
axis equal; 
grid on;
view(160,35);