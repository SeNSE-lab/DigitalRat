RatMap_Head_README
==================

Brian Quist
March 25, 2011

* Head scanned by Blythe Towal
* Data processed by Rafay Faruqi
* Point-cloud to trimesh achieved using: http://www.mathworks.com/matlabcentral/fileexchange/22595-surface-reconstruction-from-scattered-points-cloud-part2

The Hartmann Laboratory - http://www.mech.northwestern.edu/hartmann/  

1. .ZIP Contents (3 files)
--------------------------
a. RatMap_Head_README		~ Text readme file
b. Plot_RatMap_Head.m		~ MATLAB script to plot the rat head surface
c. RatMap_Head.mat		~ MATLAT .mat file containing the surface data

2. Getting started
------------------

Place the unzipped files within the same directory. 
In the command line, type:

	Plot_RatMap_Head

You should now see a 3D surface of the rat head.
This can be used directly with the command Plot_RatMap, as the head has been scaled and aligned to match the RatMap ellipsoid dataset.